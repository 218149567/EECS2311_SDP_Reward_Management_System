package layer1;

public class Default {

}

class User{
	String name;
	int value;
	int userID;
	
	public User(String name, int value, int userID) {
		this.name = name;
		this.value = value;
		this.userID = userID;
	}
	
	public int getUserID() {
		return userID;
	}
	
	public String getName() {
		return name;
	}
	
	public int getValue() {
		return value;
	}
}
